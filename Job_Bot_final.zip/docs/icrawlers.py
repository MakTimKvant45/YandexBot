import os
from icrawler.builtin import GoogleImageCrawler, GoogleParser

google_crawler = GoogleImageCrawler(storage={'root_dir': 'docs/photo'})
quabitty = 1


def get_vac_photo(name):
    google_crawler.crawl(keyword=name, max_num=quabitty)


def delete_photo(fl):
    os.remove('docs/photo/{}'.format(fl))
