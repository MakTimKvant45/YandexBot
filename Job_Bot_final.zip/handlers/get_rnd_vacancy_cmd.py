import os
import time
from aiogram.filters import Command
from aiogram.filters.text import Text
from aiogram import Router, types, F
from aiogram.types import Message, ReplyKeyboardRemove, InputFile
from aiogram.types import FSInputFile, URLInputFile
from database.get_vacancy import get_rnd_vacancy
from database.get_user_info import get_worker_city, is_worker_in_db
from database.get_user_info import is_turbo_mode, get_last_vacancy
from database.set_user_info import set_last_vacancy
from database.get_vacancy_info import get_vacancy_contact
from keyboards.like_dislike import like_dislike
from docs.icrawlers import delete_photo, get_vac_photo
from docs.yandeximage import get_all_images
from aiogram.utils.text_decorations import MarkdownDecoration

router = Router()


@router.message(Command("get_random"))
async def cmd_get_random(message: Message, have_user_id=False):
    # print(message)
    # global user_msg
    # user_msg.clear()
    user_id = message.from_user.id
    if have_user_id is not False:
        user_id = have_user_id
    if not is_worker_in_db(user_id):
        await message.answer("Ошибка! Вы не создали вакансию, пропишите /start")
    vac = get_rnd_vacancy(user_id)
    if type(vac) == list:
        await message.answer("Похоже, информации о таком городе нет, попробуйте поменять город в настройках")
        return
    # msg = "\n".join(map(str, vac[1:6]))
    # msg_l = msg.split('\n')
    msg_l = []
    md = MarkdownDecoration()
    msg_l.append(md.bold(md.quote(vac["vacancy_name"])))
    msg_l.append(md.bold(md.quote("Требования: ")) + md.quote(vac["requirement"]))
    msg_l.append(md.bold(md.quote("Обязанности: ")) + md.quote(vac["responsibility"]))
    msg_l.append(md.bold(md.quote("Зарплата: ")) + md.quote(str(vac["salary"])) + '₽')
    msg_l.append(md.bold(md.quote("Наниматель: ")) + md.quote(vac["employer"]))
    msg = "\n".join(msg_l)

    if is_turbo_mode(str(user_id)) == 1:
        set_last_vacancy(str(user_id), vac["id"])
        await message.answer(msg, reply_markup=like_dislike(), parse_mode="MarkdownV2")
    else:
        city = get_worker_city(user_id)
        url = get_all_images(vac["employer"], city)[0]
        time.sleep(0.5)
        try:
            if 'noindex' not in url:
                photo1 = URLInputFile(url)
                set_last_vacancy(str(user_id), vac["id"])
                await message.answer_photo(photo=photo1, caption=msg, reply_markup=like_dislike(),
                                           parse_mode="MarkdownV2")
            else:
                get_vac_photo(vac[5])
                file_name = ''
                for fl in os.listdir('docs/photo'):
                    file_name = fl

                print('docs/photo/{}'.format(file_name))
                photo = FSInputFile('docs/photo/{}'.format(file_name))
                set_last_vacancy(str(user_id), vac["id"])

                await message.answer_photo(photo=photo, caption=msg, reply_markup=like_dislike(),
                                           parse_mode="MarkdownV2")
                delete_photo(file_name)

        except IndexError:
            set_last_vacancy(str(user_id), vac["id"])
            await message.answer(msg, reply_markup=like_dislike(), parse_mode="MarkdownV2")


@router.message(Text("👍"))
async def get_worker_form(message: Message):
    md = MarkdownDecoration()
    if get_last_vacancy(message.from_user.id):
        await message.answer(f"*Подробнее:* \n{md.quote(get_vacancy_contact(get_last_vacancy(message.from_user.id)))}",
                             parse_mode="MarkdownV2", disable_web_page_preview=True)
    else:
        await message.answer("Введите команду /get_random для получения первой анкеты")
    await cmd_get_random(message)


@router.message(Text("👎"))
async def get_worker_form(message: Message):
    await cmd_get_random(message)
