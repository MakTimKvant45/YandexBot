import logging

from aiogram import Router, types, F
from aiogram.filters import Command
from aiogram.filters.text import Text
from aiogram.types import Message, ReplyKeyboardRemove
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from keyboards.for_new_form_kb import get_new_form_kb
from aiogram.utils.text_decorations import MarkdownDecoration

from database.get_user_info import get_user_name, get_user_about, is_turbo_mode, get_user_vacancies
from database.set_user_info import set_user_city, set_user_min_salary, set_turbo_mode
from database.get_vacancy_info import get_vacancy_name
from keyboards.settings_kb import get_settings_kb
from keyboards.vacancies_list import get_vacancies_list_kb
from handlers.get_rnd_vacancy_cmd import cmd_get_random

from pprint import pprint

router = Router()  # [1]


@router.message(Text("⚙"))
async def open_settings(message: Message):
    md = MarkdownDecoration()
    await message.answer(
        f"*Найстройки⚙*\n*Имя:* {md.quote(get_user_name(message.from_user.id))}\n*О себе:* {md.quote(get_user_about(message.from_user.id))}",
        reply_markup=get_settings_kb(message.from_user.id), parse_mode="MarkdownV2")


class WaitNewCity(StatesGroup):
    inputCity = State()


# Callback обработчик клавиатуры для замены города
@router.callback_query(Text("update_user_city"))
async def check_city_button(callback: types.CallbackQuery, state: FSMContext):
    await callback.message.answer("Введите город для поиска 🔎")
    await callback.answer()
    # Перевод в редим ожидания города
    await state.set_state(WaitNewCity.inputCity)


# Ловит город
@router.message(WaitNewCity.inputCity, F.text)
async def get_city(message: Message, state: FSMContext):
    await message.answer("Город изменен 🖊️")
    set_user_city(message.from_user.id, message.text)
    await state.clear()


class WaitNewMinSalary(StatesGroup):
    inputSalary = State()


# Callback обработчик клавиатуры для замены города
@router.callback_query(Text("update_user_min_salary"))
async def check_salary_button(callback: types.CallbackQuery, state: FSMContext):
    await callback.message.answer("Введите минимальную зарплату в ₽")
    await callback.answer()
    # Перевод в редим ожидания зарплаты
    await state.set_state(WaitNewMinSalary.inputSalary)


# Ловит новую зарплату
@router.message(WaitNewMinSalary.inputSalary, F.text)
async def get_salary(message: Message, state: FSMContext):
    if message.text.isdigit():
        await message.answer("Зарплата изменена 🖊️")
        set_user_min_salary(message.from_user.id, int(message.text))
        await state.clear()
    else:
        await message.answer("Зарплата должна быть в числовом формате!")
        await state.set_state(WaitNewMinSalary.inputSalary)


# Callback обработчик клавиатуры для продолжения поиска вакансии
@router.callback_query(Text("continue"))
async def continue_watch(callback: types.CallbackQuery):
    await cmd_get_random(callback.message, callback.from_user.id)
    await callback.answer()


# Callback обработчик клавиатуры для турбо редима
@router.callback_query(Text("update_turbo_mode"))
async def update_turbo_mode(callback: types.CallbackQuery):
    if is_turbo_mode(str(callback.from_user.id)):
        await callback.answer("Турбо режим выключен❌")
        set_turbo_mode(callback.from_user.id, False)
    else:
        await callback.answer("Турбо режим включен ✅")
        set_turbo_mode(callback.from_user.id, True)
    await callback.answer()


# Callback обработчик клавиатуры для продолжения поиска вакансии
@router.callback_query(Text("get_user_vacancies"))
async def get_user_vacancies_callback(callback: types.CallbackQuery):
    vacancies_list = get_user_vacancies(callback.from_user.id)
    if len(vacancies_list) == 0:
        await callback.message.answer("Вы не создали ни одной вакансии")
    else:
        md = MarkdownDecoration()
        msg = "Список ваших вакансий ✏\n" + md.quote("Для удаления используйте команду /del_id <id вакансии>\n")
        for num, vac in enumerate(vacancies_list):
            msg += f"*{num + 1}\)* {md.quote(get_vacancy_name(vac[0]))} {md.quote(f'- ID ')}{md.code(vac[0])} \n"
        await callback.message.answer(msg, parse_mode="MarkdownV2")
        # await callback.message.answer("*Список ваших вакансий\.*\nНажмите кнопку, чтобы удалить ваканию",
        #                               reply_markup=get_vacancies_list_kb(vacancies_list), parse_mode="MarkdownV2")
    await callback.answer()
