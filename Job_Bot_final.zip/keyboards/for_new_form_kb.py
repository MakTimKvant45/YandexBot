from aiogram import types
from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder


def get_new_form_kb() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.add(types.InlineKeyboardButton(
        text="Ищу работу🔎",
        callback_data="create_form_worker")
    )
    builder.add(types.InlineKeyboardButton(
        text="Создать вакансию📋",
        callback_data="create_vacancy")
    )
    return builder.as_markup()