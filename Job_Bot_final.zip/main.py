import asyncio
import logging

from aiogram import Bot, Dispatcher

# Импорты из наших файлов
from handlers import on_start, get_rnd_vacancy_cmd, settings_update_handler,  delete_vacancy_handler

# Включаем логирование, чтобы не пропустить важные сообщения

logging.basicConfig(level=logging.INFO)
# Объект бота
TOKEN = "6052316365:AAFz2zIY-5kJXCNyCF9crtpUuV_hRTy_Q0s"
bot = Bot(token=TOKEN)
# Диспетчер
dp = Dispatcher()


# Запуск процесса поллинга новых апдейтов
async def main():
    dp.include_routers(on_start.router, get_rnd_vacancy_cmd.router, settings_update_handler.router, delete_vacancy_handler.router)
    await dp.start_polling(bot, handle_as_tasks=True)


if __name__ == "__main__":
    asyncio.run(main())
    # loop = asyncio.get_event_loop()
    # loop.create_task(main())
    # asyncio.
