import sqlite3

DB_URL = "database/YandexBot.sqlite3"


def add_vacancy_info(data: dict, owner_telegram_id=None):
    conn = sqlite3.connect(DB_URL)
    cur = conn.cursor()
    cur.execute(
        """INSERT INTO vacancies (vacancy_name, requirement, responsibility, salary, employer, url, city_name, owner_telegram_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (data["vacancy_name"], data["requirement"], data["responsibility"], data["salary"], data["employer"],
         data["url"], data["city_name"], owner_telegram_id))
    conn.commit()
    cur.close()