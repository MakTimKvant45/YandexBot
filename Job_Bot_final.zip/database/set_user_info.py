import sqlite3


def set_last_vacancy(user_id: str, vacancy_id: int):
    conn = sqlite3.connect("database/YandexBot.sqlite3")
    cur = conn.cursor()
    cur.execute("UPDATE workers SET last_vacancy_id = (?) WHERE user_id = (?)", (vacancy_id, user_id))
    conn.commit()
    cur.close()


def set_user_city(user_id: int, city_name: str):
    conn = sqlite3.connect("database/YandexBot.sqlite3")
    cur = conn.cursor()
    cur.execute("UPDATE workers SET user_city = (?) WHERE user_id = (?)", (city_name, user_id))
    conn.commit()
    cur.close()


def set_user_min_salary(user_id: int, salary: int):
    conn = sqlite3.connect("database/YandexBot.sqlite3")
    cur = conn.cursor()
    cur.execute("UPDATE workers SET min_salary = (?) WHERE user_id = (?)", (salary, user_id))
    conn.commit()
    cur.close()


def set_turbo_mode(user_id: int, mode: bool):
    conn = sqlite3.connect("database/YandexBot.sqlite3")
    cur = conn.cursor()
    cur.execute("UPDATE workers SET turbo_mode = (?) WHERE user_id = (?)", (mode, user_id))
    conn.commit()
    cur.close()
